package sep2023;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class password {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;
	private JLabel savedUsernameLabel;
	private String[] ar = new String[100];

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					password window = new password();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public password() {
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 926, 598);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("UserName");
		lblNewLabel.setBounds(28, 44, 61, 26);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Enter password");
		lblNewLabel_1.setBounds(28, 90, 79, 26);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Confirm Password");
		lblNewLabel_2.setBounds(28, 126, 79, 24);
		frame.getContentPane().add(lblNewLabel_2);
		JLabel lblNewLabel_7 = new JLabel("");
		textField = new JTextField();
		textField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				
				boolean flag=false;
				for(String s:ar)
				{
					if(textField.getText().equalsIgnoreCase(s))
					{
						lblNewLabel_7.setForeground(Color.RED);
						lblNewLabel_7.setText("UserName already exists");
						flag=true;
						break;
					}
				}
				if(flag==false)
				{
					lblNewLabel_7.setForeground(Color.GREEN);
					lblNewLabel_7.setText("UserName Available");
					flag=true;
					
				}
				
				String username = textField.getText();
                boolean exists = false;

                for (String s : ar) {
                    if (s != null && s.equalsIgnoreCase(username)) {
                        exists = true;
                        break;
                    }
                }

                if (!exists) {
                    for (int i = 0; i < ar.length; i++) {
                        if (ar[i] == null) {
                            ar[i] = username;
                            break;
                        }
                    }
                    JOptionPane.showMessageDialog(frame, "Username saved!");
                }
                
                displayArrayContents();
				
				
			}
		});
		textField.setBounds(129, 48, 96, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		savedUsernameLabel = new JLabel("");
        savedUsernameLabel.setBounds(28, 200, 300, 26);
        frame.getContentPane().add(savedUsernameLabel);
        
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setBounds(311, 158, 85, 21);
		frame.getContentPane().add(btnNewButton);
		JLabel lblNewLabel_3 = new JLabel("Contains One Upper Case letter");
		JLabel lblNewLabel_4 = new JLabel("Contains One Lower Case Letter");
		JLabel lblNewLabel_5 = new JLabel("Contains One Number");
		JLabel lblNewLabel_6 = new JLabel("Contains One special character");
		lblNewLabel_3.setForeground(Color.RED);
		lblNewLabel_4.setForeground(Color.RED);
		lblNewLabel_5 .setForeground(Color.RED);
		lblNewLabel_6 .setForeground(Color.RED);
		
		passwordField = new JPasswordField();
		passwordField.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(KeyEvent e) {
		        String s = passwordField.getText();
		        int UCount = 0, LCount = 0, NCount = 0, SCount = 0;
		        for (int i = 0; i < s.length(); i++) {
		            char c = s.charAt(i);

		            if (Character.isDigit(c))
		                NCount += 1;
		            else if (Character.isAlphabetic(c)) {
		                if (Character.isUpperCase(c))
		                    UCount += 1;
		                else
		                    LCount += 1;
		            } else
		                SCount += 1;
		        }

		        if (UCount == 1)
		            lblNewLabel_3.setForeground(Color.GREEN);
		        else
		            lblNewLabel_3.setForeground(Color.RED);

		        if (LCount == 1)
		            lblNewLabel_4.setForeground(Color.GREEN);
		        else
		            lblNewLabel_4.setForeground(Color.RED);
		        if (NCount == 1)
		            lblNewLabel_5.setForeground(Color.GREEN);
		        else
		            lblNewLabel_5.setForeground(Color.RED);
		        if (SCount == 1)
		            lblNewLabel_6.setForeground(Color.GREEN);
		        else
		            lblNewLabel_6.setForeground(Color.RED);
		    }
		});

		passwordField.setBounds(129, 90, 96, 19);
		frame.getContentPane().add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(129, 129, 96, 19);
		frame.getContentPane().add(passwordField_1);
		
		
		lblNewLabel_3.setBounds(52, 243, 250, 40);
		frame.getContentPane().add(lblNewLabel_3);
		
		
		lblNewLabel_4.setBounds(52, 305, 184, 40);
		frame.getContentPane().add(lblNewLabel_4);
		
		
		lblNewLabel_5.setBounds(52, 361, 144, 33);
		frame.getContentPane().add(lblNewLabel_5);
		
		
		lblNewLabel_6.setBounds(52, 411, 217, 33);
		frame.getContentPane().add(lblNewLabel_6);
		
		
		lblNewLabel_7.setBounds(289, 44, 301, 20);
		frame.getContentPane().add(lblNewLabel_7);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setToolTipText("");
		frame.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Password");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("New menu item");
		mnNewMenu.add(mntmNewMenuItem);
		
		
	
	
}
private void displayArrayContents() {
    StringBuilder sb = new StringBuilder();
    for (String s : ar) {
        if (s != null) {
            sb.append(s).append(", ");
        }
    }

    if (sb.length() > 0) {
        sb.setLength(sb.length() - 2); // Remove the last ", "
    }

    savedUsernameLabel.setText("Array Contents: " + sb.toString());
}
}
