package sep2023;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class multiple {

    private JFrame frame;
    private JPanel quizPanel; // Quiz panel added
    

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    multiple window = new multiple();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public multiple() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
    	frame = new JFrame();
        frame.setBounds(100, 100, 550, 500); // Increase the dimensions of the frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        String user="";

        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setBounds(10, 10, 376, 243);
        frame.getContentPane().add(tabbedPane);

        JPanel panel_1 = new JPanel();
        panel_1.setBounds(10, 41, 500, 400);
        tabbedPane.addTab("DAY 1 ", null, panel_1, null);
        panel_1.setLayout(null);
        
        JButton btnNewButton_5 = new JButton("STANDARD MATHEMATICAL AND THEORETICAL CALUCULATIONS");
        btnNewButton_5.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		new nani();
            	frame.setVisible(false);
        		
        	}
        });
        btnNewButton_5.setBounds(10, 70, 351, 90);
        panel_1.add(btnNewButton_5);

        // Quiz panel
        quizPanel = new JPanel();
        quizPanel.setBounds(10, 10, 516, 442); 
        // Increase the dimensions of the quiz panel
        
        frame.getContentPane().add(quizPanel);
        quizPanel.setLayout(null);

        

        JPanel panel_2 = new JPanel();
        tabbedPane.addTab("DAY 2", null, panel_2, null);
        panel_2.setLayout(null);
        
        JButton btnNewButton_3 = new JButton("QUIZ");
        btnNewButton_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		new quiz(user);
	        	frame.setVisible(false);
        	}
        });
        btnNewButton_3.setBounds(95, 75, 128, 50);
        panel_2.add(btnNewButton_3);
        
                JPanel panel = new JPanel();
                tabbedPane.addTab("DAY 3", null, panel, null);
                
                        JButton btnNewButton = new JButton("Mouse");
                        btnNewButton.setBounds(40, 26, 85, 21);
                        btnNewButton.addMouseListener(new MouseAdapter() {
                            @Override
                            public void mouseEntered(MouseEvent e) {
                                btnNewButton.setBackground(Color.RED);
                                btnNewButton.setBounds(e.getX(), e.getY(), 80, 30);
                            }

                            @Override
                            public void mouseExited(MouseEvent e) {
                                btnNewButton.setBackground(Color.GREEN);
                            }

                            @Override
                            public void mouseClicked(MouseEvent e) {
                                if (e.getButton() == 1) {
                                    btnNewButton.setText("Left Click");
                                } else if (e.getButton() == 3) {
                                    btnNewButton.setText("Right Click");
                                }
                            }
                        });
                        panel.setLayout(null);
                        panel.add(btnNewButton);
                                
                                JButton btnNewButton_2 = new JButton("FILE OPERATIONS AND DATA OPERATIONS");
                                btnNewButton_2.addActionListener(new ActionListener() {
                                	public void actionPerformed(ActionEvent e) {
                                		new file();
                                    	frame.setVisible(false);
                                		
                                	}
                                });
                                btnNewButton_2.setBounds(32, 76, 296, 89);
                                panel.add(btnNewButton_2);
                                
                                JPanel panel_3 = new JPanel();
                                tabbedPane.addTab("DAY 4", null, panel_3, null);
                                panel_3.setLayout(null);
                                
                                JButton btnNewButton_4 = new JButton("DATA BASES LOADER");
                                btnNewButton_4.addActionListener(new ActionListener() {
                                	public void actionPerformed(ActionEvent e) {
                                		new Databases();
                                    	frame.setVisible(false);
                                	}
                                });
                                btnNewButton_4.setBounds(87, 80, 179, 49);
                                panel_3.add(btnNewButton_4);
                                
                                JPanel panel_4 = new JPanel();
                                tabbedPane.addTab("DAY 5", null, panel_4, null);
                                panel_4.setLayout(null);
                                
                                JButton btnNewButton_1 = new JButton("All BACKEND OPERATIONS");
                                btnNewButton_1.addActionListener(new ActionListener() {
                                	public void actionPerformed(ActionEvent e) {
                                		new Totalbackend();
                                		frame.setVisible(false);
                                	}
                                });
                                btnNewButton_1.setBounds(62, 51, 234, 99);
                                panel_4.add(btnNewButton_1);
        
        frame.setBounds(100, 100, 547, 540);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
