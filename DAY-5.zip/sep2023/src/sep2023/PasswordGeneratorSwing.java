package sep2023;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class PasswordGeneratorSwing extends JFrame {
    private JCheckBox uppercaseCheckbox;
    private JCheckBox lowercaseCheckbox;
    private JCheckBox numbersCheckbox;
    private JCheckBox symbolsCheckbox;
    private JComboBox<String> strengthComboBox;
    private JButton generateButton;
    private JTextField passwordField;

    public PasswordGeneratorSwing() {
        setTitle("Password Generator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Checkboxes
        uppercaseCheckbox = new JCheckBox("Include Uppercase");
        lowercaseCheckbox = new JCheckBox("Include Lowercase");
        numbersCheckbox = new JCheckBox("Include Numbers");
        symbolsCheckbox = new JCheckBox("Include Symbols");

        // Combo box
        strengthComboBox = new JComboBox<>();
        strengthComboBox.addItem("Weak");
        strengthComboBox.addItem("Medium");
        strengthComboBox.addItem("Strong");

        // Generate button
        generateButton = new JButton("Generate Password");
        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generatePassword();
            }
        });

        // Password field
        passwordField = new JTextField(20);
        passwordField.setEditable(false);

        // Add components to the frame
        add(uppercaseCheckbox);
        add(lowercaseCheckbox);
        add(numbersCheckbox);
        add(symbolsCheckbox);
        add(new JLabel("Strength:"));
        add(strengthComboBox);
        add(generateButton);
        add(passwordField);

        pack();
        setVisible(true);
    }

    private void generatePassword() {
        int length;
        boolean uppercase = uppercaseCheckbox.isSelected();
        boolean lowercase = lowercaseCheckbox.isSelected();
        boolean numbers = numbersCheckbox.isSelected();
        boolean symbols = symbolsCheckbox.isSelected();
        String strength = (String) strengthComboBox.getSelectedItem();

        StringBuilder charset = new StringBuilder();
        StringBuilder password = new StringBuilder();

        if (uppercase) charset.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
        if (lowercase) charset.append("abcdefghijklmnopqrstuvwxyz");
        if (numbers) charset.append("0123456789");
        if (symbols) charset.append("!@#$%^&*()_+~`|}{[]:;?><,./-=");

        if (charset.length() == 0) {
            JOptionPane.showMessageDialog(this, "Please select at least one option.");
            return;
        }

        if (strength.equals("Medium")) length = 10;
        else if (strength.equals("Strong")) length = 14;
        else length = 6;

        Random random = new Random();
        for (int i = 0; i < length; i++) {
            int index = random.nextInt(charset.length());
            password.append(charset.charAt(index));
        }

        passwordField.setText(password.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PasswordGeneratorSwing();
            }
        });
    }
}
