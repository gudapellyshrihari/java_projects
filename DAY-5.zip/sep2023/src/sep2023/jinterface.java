package sep2023;

import java.sql.Statement;
import javax.swing.ListSelectionModel;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ComboBoxModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class jinterface {
    private JFrame frame;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField textField_3;
    private JTextField textField_4;
    private JTextField textField_5;
    private JTextField textField_6;
    private int selectedRow ;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    jinterface window = new jinterface();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public jinterface() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 559, 544);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        String[] columnsName = { "RollNo", "Name", "City", "Gender", "Contact" };

        JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.setBounds(21, 11, 495, 496);
        frame.getContentPane().add(tabbedPane);

        JPanel panel = new JPanel();
        tabbedPane.addTab("New tab", null, panel, null);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("RollNo");
        lblNewLabel.setBounds(21, 25, 48, 14);
        panel.add(lblNewLabel);

        textField = new JTextField();
        textField.setBounds(106, 22, 96, 20);
        panel.add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel_1 = new JLabel("Name");
        lblNewLabel_1.setBounds(21, 65, 48, 14);
        panel.add(lblNewLabel_1);

        textField_1 = new JTextField();
        textField_1.setText("");
        textField_1.setBounds(106, 62, 96, 20);
        panel.add(textField_1);
        textField_1.setColumns(10);

        JLabel lblNewLabel_2 = new JLabel("City");
        lblNewLabel_2.setBounds(21, 102, 48, 14);
        panel.add(lblNewLabel_2);

        String[] cities = { "Udaipur", "Jaipur", "Chandigarh", "Amritsar" };

        JComboBox comboBox = new JComboBox(cities);

        comboBox.setBounds(106, 98, 96, 22);
        panel.add(comboBox);

        JLabel lblNewLabel_3 = new JLabel("Gender");
        lblNewLabel_3.setBounds(21, 141, 48, 14);
        panel.add(lblNewLabel_3);

        JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
        rdbtnNewRadioButton.setSelected(true);
        rdbtnNewRadioButton.setBounds(93, 137, 109, 23);
        panel.add(rdbtnNewRadioButton);

        JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Female");
        rdbtnNewRadioButton_1.setBounds(202, 137, 109, 23);
        panel.add(rdbtnNewRadioButton_1);

        JButton btnNewButton = new JButton("Submit");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int roll = Integer.parseInt(textField.getText());
                String name = textField_1.getText();
                String city = (String) comboBox.getSelectedItem();
                char gen = 'M';
                if (rdbtnNewRadioButton.isSelected())
                    gen = 'M';
                else
                    gen = 'F';

                long contact = Long.parseLong(textField_2.getText());
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root",
                            "OerB2969+1");
                    PreparedStatement ps = con.prepareStatement("insert into data values(?,?,?,?,?)");
                    ps.setInt(1, roll);
                    ps.setString(2, name);
                    ps.setString(3, city);
                    ps.setString(4, String.valueOf(gen));
                    ps.setLong(5, contact);
                    int n = ps.executeUpdate();
                    if (n > 0)
                        JOptionPane.showMessageDialog(frame, "Record Inserted Successfully");

                    // Refresh the table
                    refreshTable(con);

                } catch (SQLException e1) {
                    e1.printStackTrace();
                }

            }
        });
        btnNewButton.setBounds(106, 235, 89, 23);
        panel.add(btnNewButton);

        textField_2 = new JTextField();
        textField_2.setBounds(106, 183, 96, 20);
        panel.add(textField_2);
        textField_2.setColumns(10);

        JLabel lblNewLabel_4 = new JLabel("Contact");
        lblNewLabel_4.setBounds(21, 186, 48, 14);
        panel.add(lblNewLabel_4);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(21, 302, 459, 157);
        panel.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);
        table.setEnabled(true);
        table.setFocusable(false);

        JLabel lblNewLabel_5 = new JLabel("DISPLAYING THE DATA:");
        lblNewLabel_5.setBounds(27, 279, 284, 13);
        panel.add(lblNewLabel_5);

        JButton btnNewButton_1 = new JButton("UPDATE");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "No row selected!");
                    return;
                }

                int roll = Integer.parseInt(textField.getText());
                String name = textField_1.getText();
                String city = (String) comboBox.getSelectedItem();
                char gen = 'M';
                if (rdbtnNewRadioButton.isSelected())
                    gen = 'M';
                else
                    gen = 'F';

                long contact = Long.parseLong(textField_2.getText());
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root",
                            "OerB2969+1");
                    PreparedStatement ps = con.prepareStatement(
                            "update data set Name=?, City=?, Gender=?, Contact=? where Rno=?");
                    ps.setString(1, name);
                    ps.setString(2, city);
                    ps.setString(3, String.valueOf(gen));
                    ps.setLong(4, contact);
                    ps.setInt(5, roll);

                    int n = ps.executeUpdate();
                    if (n > 0)
                        JOptionPane.showMessageDialog(frame, "Record Updated Successfully");

                    refreshTable(con);

                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        });
        btnNewButton_1.setBounds(312, 40, 85, 21);
        panel.add(btnNewButton_1);

        JButton btnNewButton_2 = new JButton("DELETE");
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "No row selected!");
                    return;
                }

                int roll = Integer.parseInt(textField.getText());
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root",
                            "OerB2969+1");
                    PreparedStatement ps = con.prepareStatement("delete from data where Rno=?");
                    ps.setInt(1, roll);
                    int n = ps.executeUpdate();
                    if (n > 0)
                        JOptionPane.showMessageDialog(frame, "Record Deleted Successfully");

                    refreshTable(con);

                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        });
        btnNewButton_2.setBounds(312, 99, 85, 21);
        panel.add(btnNewButton_2);

        JButton btnNewButton_11 = new JButton("Edit");
        btnNewButton_11.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "No row selected!");
                    return;
                }

                textField.setEditable(true);
                textField_1.setEditable(true);
                comboBox.setEnabled(true);
                rdbtnNewRadioButton.setEnabled(true);
                rdbtnNewRadioButton_1.setEnabled(true);
                textField_2.setEditable(true);
            }
        });
        btnNewButton_11.setBounds(317, 159, 85, 21);
        panel.add(btnNewButton_11);

        tableModel = new DefaultTableModel(columnsName, 0);
        table.setModel(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
        tabbedPane.addTab("New tab", null, tabbedPane_1, null);
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent event) {
                if (!event.getValueIsAdjusting()) {
                    selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        textField.setText(table.getValueAt(selectedRow, 0).toString());
                        textField_1.setText(table.getValueAt(selectedRow, 1).toString());
                        comboBox.setSelectedItem(table.getValueAt(selectedRow, 2).toString());

                        String gender = table.getValueAt(selectedRow, 3).toString();
                        if (gender.equals("M")) {
                            rdbtnNewRadioButton.setSelected(true);
                            rdbtnNewRadioButton_1.setSelected(false);
                        } else {
                            rdbtnNewRadioButton.setSelected(false);
                            rdbtnNewRadioButton_1.setSelected(true);
                        }

                        textField_2.setText(table.getValueAt(selectedRow, 4).toString());
                    }
                }
            }
        });



        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root", "OerB2969+1");
            refreshTable(con);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshTable(Connection con) {
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from data");

            DefaultTableModel tableModel = (DefaultTableModel) table.getModel();
            tableModel.setRowCount(0);

            while (rs.next()) {
                int roll = rs.getInt("Rno");
                String name = rs.getString("name");
                String city = rs.getString("city");
                String gen = rs.getString("gender");
                long contact = rs.getLong("contact");

                Object[] rowData = { roll, name, city, gen, contact };
                tableModel.addRow(rowData);
            }

            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
