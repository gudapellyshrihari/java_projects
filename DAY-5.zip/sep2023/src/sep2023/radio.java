package sep2023;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class radio {

    private JFrame frame;
    private JRadioButton rdbtnNewRadioButton;
    private JRadioButton rdbtnNewRadioButton_1;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    radio window = new radio();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public radio() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        ButtonGroup bg = new ButtonGroup();
        JButton btnNewButton_1 = new JButton("Radio");
        btnNewButton_1.addItemListener(new ItemListener() {
        	public void itemStateChanged(ItemEvent e) {
        		frame.getContentPane().setBackground(Color.yellow);
        	}
        });
       

        rdbtnNewRadioButton = new JRadioButton("Red");
        rdbtnNewRadioButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		frame.getContentPane().setBackground(Color.RED);
        	}
        });
        rdbtnNewRadioButton.setBounds(74, 61, 103, 21);
        frame.getContentPane().add(rdbtnNewRadioButton);
        bg.add(rdbtnNewRadioButton);

        rdbtnNewRadioButton_1 = new JRadioButton("Blue");
        rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		frame.getContentPane().setBackground(Color.BLUE);
        	}
        });
        rdbtnNewRadioButton_1.setBounds(74, 127, 103, 21);
        frame.getContentPane().add(rdbtnNewRadioButton_1);
        bg.add(rdbtnNewRadioButton_1);

        btnNewButton_1.setBounds(134, 179, 85, 21);
        frame.getContentPane().add(btnNewButton_1);
    }
}
