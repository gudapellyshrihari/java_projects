package sep2023;

import java.awt.EventQueue;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class checkbox {
    private JFrame frame;
    private JTextField textField;
    double amount = 0;
    private JLabel imageLabel;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    checkbox window = new checkbox();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public checkbox() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        

        JCheckBox chckbxNewCheckBox = new JCheckBox("Cool Drink-100");
        chckbxNewCheckBox.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {

                double amount = Double.parseDouble(textField.getText());
                if (e.getStateChange() == 1) {
                    amount += 100;
                    textField.setText(String.valueOf(amount));
                }
                if (e.getStateChange() == 2) {
                    amount -= 100;
                    textField.setText(String.valueOf(amount));
                }
            }
        });
        chckbxNewCheckBox.setBounds(201, 52, 160, 21);
        frame.getContentPane().add(chckbxNewCheckBox);

        JCheckBox chckbxNewCheckBox_1 = new JCheckBox("Pizza-250");
        chckbxNewCheckBox_1.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                double amount = Double.parseDouble(textField.getText());
                if (e.getStateChange() == 1) {
                    amount += 250;
                    textField.setText(String.valueOf(amount));
                }
                if (e.getStateChange() == 2) {
                    amount -= 250;
                    textField.setText(String.valueOf(amount));
                }
            }
        });
        chckbxNewCheckBox_1.setBounds(201, 103, 93, 21);
        frame.getContentPane().add(chckbxNewCheckBox_1);

        JCheckBox chckbxNewCheckBox_2 = new JCheckBox("Burger-550");
        chckbxNewCheckBox_2.addItemListener(new ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                double amount = Double.parseDouble(textField.getText());
                if (e.getStateChange() == 1) {
                    amount += 550;
                    textField.setText(String.valueOf(amount));
                }
                if (e.getStateChange() == 2) {
                    amount -= 550;
                    textField.setText(String.valueOf(amount));
                }
            }
        });
        chckbxNewCheckBox_2.setBounds(201, 151, 93, 21);
        frame.getContentPane().add(chckbxNewCheckBox_2);

        JButton btnNewButton = new JButton("Total Amount");
        btnNewButton.addActionListener(e -> {
            // Perform any actions you want when the button is clicked
        });
        btnNewButton.setBounds(118, 198, 123, 28);
        frame.getContentPane().add(btnNewButton);

        textField = new JTextField();
        textField.setText("0");
        textField.setBounds(265, 203, 96, 19);
        frame.getContentPane().add(textField);
        textField.setColumns(10);

        JLabel lblNewLabel = new JLabel("ONLINE ORDER:");
        lblNewLabel.setBounds(61, 10, 127, 39);
        frame.getContentPane().add(lblNewLabel);

        imageLabel = new JLabel();
        imageLabel.setBounds(10, 52, 173, 120);
        frame.getContentPane().add(imageLabel);

        try {
            Image image = ImageIO.read(new File("D:\\complete web devolopment bootcamp\\pizza.jpg"));
            Image scaledImage = image.getScaledInstance(imageLabel.getWidth(), imageLabel.getHeight(), Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaledImage));
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }
}
