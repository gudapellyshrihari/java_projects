package sep2023;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.JScrollBar;
import java.awt.event.AdjustmentListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Rrgb {

    public JFrame frame;
    public JTextField textField;
    public JTextField textField_1;
    public JTextField textField_2;
    private JTextField textField_3;
    private JTextField textField_4_1;
    private JTextField textField_5;
    private JTextField textField_6;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Rrgb window = new Rrgb();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public Rrgb() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 778, 536);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        textField = new JTextField();
        textField_1 = new JTextField();
        textField_2= new JTextField();
        textField_3 = new JTextField();
        textField_4_1 = new JTextField();
        textField_5 = new JTextField();
        textField_6 = new JTextField();
        JSlider slider = new JSlider();
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int i = slider.getValue();
                textField.setText(String.valueOf(i));
                updateTextFieldColor();
            }
        });

        slider.setMajorTickSpacing(25);
        slider.setPaintTicks(true);
        slider.setMaximum(255);
        slider.setBounds(87, 27, 192, 22);
        frame.getContentPane().add(slider);
        //textField_1 = new JTextField();
        JSlider slider_1 = new JSlider();
        slider_1.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int j = slider_1.getValue();
                textField_1.setText(String.valueOf(j));
                updateTextFieldColor();
            }
        });
        slider_1.setMajorTickSpacing(25);
        slider_1.setPaintTicks(true);
        slider_1.setMaximum(255);
        slider_1.setBounds(87, 94, 200, 22);
        frame.getContentPane().add(slider_1);
        //textField_2 = new JTextField();
        JSlider slider_2 = new JSlider();
        slider_2.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int k = slider_2.getValue();
                textField_2.setText(String.valueOf(k));
                updateTextFieldColor();
            }
        });
        slider_2.setMaximum(255);
        slider_2.setPaintTicks(true);
        slider_2.setMajorTickSpacing(25);
        slider_2.setBounds(87, 169, 200, 22);
        frame.getContentPane().add(slider_2);

        JButton btnNewButton = new JButton("Red");
        btnNewButton.setBounds(10, 28, 75, 21);
        frame.getContentPane().add(btnNewButton);

        JButton btnNewButton_1 = new JButton("Green");
        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });
        btnNewButton_1.setBounds(10, 94, 66, 21);
        frame.getContentPane().add(btnNewButton_1);

        JButton btnNewButton_2 = new JButton("Blue");
        btnNewButton_2.setBounds(10, 169, 66, 21);
        frame.getContentPane().add(btnNewButton_2);

        textField.setText("75");
        textField.setBounds(303, 27, 96, 19);
        frame.getContentPane().add(textField);
        textField.setColumns(10);

        textField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String text = textField.getText();
                try {
                    int value = Integer.parseInt(text);
                    if (value >= 0 && value <= 255) {
                        slider.setValue(value);
                        updateTextFieldColor();
                    }
                } catch (NumberFormatException ex) {
System.out.println("ggg");
                }
            }
        });

        textField_1.setText("75");
        textField_1.setBounds(303, 96, 96, 19);
        frame.getContentPane().add(textField_1);
        textField_1.setColumns(10);

        textField_1.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String text = textField_1.getText();
                try {
                    int value = Integer.parseInt(text);
                    if (value >= 0 && value <= 255) {
                        slider_1.setValue(value);
                        updateTextFieldColor();
                    }
                } catch (NumberFormatException ex) {

                }
            }
        });

        textField_2.setText("75");
        textField_2.setBounds(303, 167, 96, 19);
        frame.getContentPane().add(textField_2);
        textField_2.setColumns(10);

        textField_2.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String text = textField_2.getText();
                try {
                    int value = Integer.parseInt(text);
                    if (value >= 0 && value <= 255) {
                        slider_2.setValue(value);
                        updateTextFieldColor();
                    }
                } catch (NumberFormatException ex) {
                	System.out.println(ex);
                }
            }
        });

        textField_3 = new JTextField();
        //textField_3.setText("90");
        JScrollBar scrollBar = new JScrollBar();
        scrollBar.addAdjustmentListener(new AdjustmentListener() {
            public void adjustmentValueChanged(AdjustmentEvent e) {
                int i = scrollBar.getValue();
                textField_3.setText(String.valueOf(i));
                slider.setValue(i);
                updateTextFieldColor();
            }
        });
        scrollBar.setValue(255);
        scrollBar.setMaximum(255);
        scrollBar.setBounds(409, 10, 17, 48);
        frame.getContentPane().add(scrollBar);

        textField_3.setBounds(434, 27, 96, 19);
        frame.getContentPane().add(textField_3);
        textField_3.setColumns(10);
        //textField_4_1 = new JTextField();
        JScrollBar scrollBar_1 = new JScrollBar();
        scrollBar_1.setMaximum(255);
        scrollBar_1.addAdjustmentListener(new AdjustmentListener() {
            public void adjustmentValueChanged(AdjustmentEvent e) {
                int k = scrollBar_1.getValue();
                textField_4_1.setText(String.valueOf(k));
                slider_1.setValue(k);
                updateTextFieldColor();
            }
        });
        scrollBar_1.setValue(255);
        scrollBar_1.setBounds(409, 78, 17, 48);
        frame.getContentPane().add(scrollBar_1);
       // textField_5 = new JTextField();
        JScrollBar scrollBar_2 = new JScrollBar();
        scrollBar_2.setMaximum(255);
        scrollBar_2.addAdjustmentListener(new AdjustmentListener() {
            public void adjustmentValueChanged(AdjustmentEvent e) {
                int j = scrollBar_2.getValue();
                textField_5.setText(String.valueOf(j));
                slider_2.setValue(j);
                updateTextFieldColor();
            }
        });
        scrollBar_2.setValue(255);
        scrollBar_2.setBounds(409, 154, 17, 48);
        frame.getContentPane().add(scrollBar_2);

        textField_4_1.setText("90");
        textField_4_1.setBounds(434, 94, 96, 19);
        frame.getContentPane().add(textField_4_1);
        textField_4_1.setColumns(10);

        textField_5.setText("90");
        textField_5.setBounds(434, 169, 96, 19);
        frame.getContentPane().add(textField_5);
        textField_5.setColumns(10);

        //textField_6 = new JTextField();
        textField_6.setBounds(609, 28, 96, 322);
        frame.getContentPane().add(textField_6);
        textField_6.setColumns(10);
    }

    /**
     * Update the background color of the textField_6 based on the RGB values.
     */
    private void updateTextFieldColor() {
      
    	try {
    		if(!(textField.getText().equals("")||textField_1.getText().equals("")||textField_2.getText().equals("")))
    				{	int red = Integer.parseInt(textField.getText());
        int green = Integer.parseInt(textField_1.getText());
        int blue = Integer.parseInt(textField_2.getText());

        Color color = new Color(red, green, blue);
        textField_6.setBackground(color);}}
        catch(Exception e) {System.out.println("got you");}}
    
}
