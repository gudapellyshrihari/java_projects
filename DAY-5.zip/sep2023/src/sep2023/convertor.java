package sep2023;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class convertor {

	public JFrame frame;
    public JTextField textField;
    public JComboBox<String> fromComboBox;
    public JComboBox<String> toComboBox;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					convertor window = new convertor();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public convertor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setVisible(true);
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        textField = new JTextField();
        textField.setBounds(10, 11, 162, 20);
        frame.getContentPane().add(textField);
        textField.setColumns(10);

        fromComboBox = new JComboBox<String>();
        fromComboBox.setBounds(10, 42, 162, 20);
        fromComboBox.addItem("Celsius");
        fromComboBox.addItem("Fahrenheit");
        fromComboBox.addItem("Kelvin");
        frame.getContentPane().add(fromComboBox);

        toComboBox = new JComboBox<String>();
        toComboBox.setBounds(10, 73, 162, 20);
        toComboBox.addItem("Celsius");
        toComboBox.addItem("Fahrenheit");
        toComboBox.addItem("Kelvin");
        frame.getContentPane().add(toComboBox);

        JButton convertButton = new JButton("Convert");
        convertButton.setBounds(182, 42, 89, 51);
        convertButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                convertTemperature();
            }
        });
        frame.getContentPane().add(convertButton);
    }

    private void convertTemperature() {
        String temperatureInput = textField.getText();
        double temperature = Double.parseDouble(temperatureInput);

        String fromUnit = (String) fromComboBox.getSelectedItem();
        String toUnit = (String) toComboBox.getSelectedItem();

        double convertedValue;
        String convertedUnit;

        switch (fromUnit) {
            case "Celsius":
                convertedValue = convertCelsius(temperature, toUnit);
                convertedUnit = toUnit;
                break;
            case "Fahrenheit":
                convertedValue = convertFahrenheit(temperature, toUnit);
                convertedUnit = toUnit;
                break;
            case "Kelvin":
                convertedValue = convertKelvin(temperature, toUnit);
                convertedUnit = toUnit;
                break;
            default:
                convertedValue = 0;
                convertedUnit = "";
                break;
        }

        String message = convertedUnit + ": " + convertedValue;
        JOptionPane.showMessageDialog(null, message, "Temperature Conversion Result", JOptionPane.INFORMATION_MESSAGE);
    }

    private double convertCelsius(double temperature, String toUnit) {
        switch (toUnit) {
            case "Celsius":
                return temperature;
            case "Fahrenheit":
                return celsiusToFahrenheit(temperature);
            case "Kelvin":
                return celsiusToKelvin(temperature);
            default:
                return 0;
        }
    }

    private double convertFahrenheit(double temperature, String toUnit) {
        switch (toUnit) {
            case "Celsius":
                return fahrenheitToCelsius(temperature);
            case "Fahrenheit":
                return temperature;
            case "Kelvin":
                return fahrenheitToKelvin(temperature);
            default:
                return 0;
        }
    }

    private double convertKelvin(double temperature, String toUnit) {
        switch (toUnit) {
            case "Celsius":
                return kelvinToCelsius(temperature);
            case "Fahrenheit":
                return kelvinToFahrenheit(temperature);
            case "Kelvin":
                return temperature;
            default:
                return 0;
        }
    }

    private double fahrenheitToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }

    private double celsiusToFahrenheit(double celsius) {
        return celsius * 9 / 5 + 32;
    }

    private double kelvinToCelsius(double kelvin) {
        return kelvin - 273.15;
    }

    private double celsiusToKelvin(double celsius) {
        return celsius + 273.15;
    }

    private double fahrenheitToKelvin(final double fahrenheit) {
        return celsiusToKelvin(fahrenheitToCelsius(fahrenheit));
    }

    private double kelvinToFahrenheit(double kelvin) {
        return celsiusToFahrenheit(kelvinToCelsius(kelvin));
    }
}
/*
 * String temperatureInput = JOptionPane.showInputDialog(frame, "Enter the temperature:",
                        "Temperature Converter", JOptionPane.QUESTION_MESSAGE);
                double temperature = Double.parseDouble(temperatureInput);

                
                String[] unitOptions = { "Celsius", "Fahrenheit", "Kelvin" };
                String selectedUnit = (String) JOptionPane.showInputDialog(frame, "Select the unit of the temperature:",
                        "Temperature Converter", JOptionPane.QUESTION_MESSAGE, null, unitOptions, unitOptions[0]);

                double convertedValue;
                String convertedUnit;

                switch (selectedUnit) {
                    case "Celsius":
                        convertedValue = temperature;
                        convertedUnit = "Celsius";
                        break;
                    case "Fahrenheit":
                        convertedValue = fahrenheitToCelsius(temperature);
                        convertedUnit = "Fahrenheit";
                        break;
                    case "Kelvin":
                        convertedValue = kelvinToCelsius(temperature);
                        convertedUnit = "Kelvin";
                        break;
                    default:
                        convertedValue = 0;
                        convertedUnit = "";
                        break;
                }

                String message = convertedUnit + ": " + convertedValue;

                JOptionPane.showMessageDialog(null, message, "Temperature Conversion Result", JOptionPane.INFORMATION_MESSAGE);

 */
