package sep2023;

import javax.swing.JLabel;
import javax.swing.*;

import javax.swing.JFrame;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class MyfirstJframe implements ActionListener,KeyListener {

    private JTextField t1;
    private JTextField t2;
    private JTextField t3;
JButton b1,b2,b3,b4;
JFrame frame;
    public MyfirstJframe() throws Exception {
        frame = new JFrame();
        frame.setSize(400, 300);
        frame.setVisible(true);
        frame.setTitle("ShriHari");
        frame.setLocation(500, 300);
        frame.setResizable(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        
        JLabel l1 = new JLabel("1st No");
        t1 = new JTextField();
        t1.addKeyListener(this);
        b1 = new JButton("Add");
        b2 = new JButton("Clear");
        b3 = new JButton("bgcolor");
        l1.setBounds(20, 20, 150, 30);
        t1.setBounds(130, 20, 100, 30);
        b1.setBounds(60, 120, 100, 30);
        b2.setBounds(170, 120, 100, 30);
        b3.setBounds(290,10,100,30);
        
        
        JLabel l2 = new JLabel("2nd No:");
        t2 = new JTextField();
        l2.setBounds(20, 50, 150, 30);
        t2.setBounds(130, 50, 100, 30);
        
        JLabel l3 = new JLabel("Result:");
        t3 = new JTextField();
        l3.setBounds(20, 80, 150, 30);
        t3.setBounds(130, 80, 100, 30);
        
        b1.addActionListener(this);
        b3.addActionListener(this);
        
        
        
        frame.add(l1);
        frame.add(t1);
        frame.add(b1);
        frame.add(b2);
        frame.add(l2);
        frame.add(t2);
        frame.add(l3);
        frame.add(t3);
        frame.add(b3);
    }

    public static void main(String args[]) {
        try {
            new MyfirstJframe();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void keyTyped(KeyEvent e) {
    	if(!Character.isDigit(e.getKeyChar()))
    		e.consume();
    }

   
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1)
        {
        	int n=JOptionPane.showConfirmDialog(frame,"do you want to add ?","exit",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
        	if(n==0)
        	{
        		String text1 = t1.getText();
                int i=Integer.parseInt(text1);
                
                String text2 = t2.getText();
                int j=Integer.parseInt(text2);
                int c=i+j;
                
                t3.setText(String.valueOf(c));
                System.out.println(String.valueOf(c));
                JOptionPane.showMessageDialog(frame,"Sum of "+i+" and "+j+" is "+c,"Question",JOptionPane.QUESTION_MESSAGE);
        		
        	}
        	else if(n==1)
        	{
        		System.out.println("error");
        		JOptionPane.showMessageDialog(frame,"thank you","BEST WISHES",JOptionPane.QUESTION_MESSAGE);
                t1.setText("");
                t2.setText("");
                t3.setText("");
        	}
        	
        }
        if(e.getSource()==b3)
        {
        	frame.getContentPane().setBackground(Color.YELLOW);
        }
        
    }

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}