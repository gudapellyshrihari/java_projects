package sep2023;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.Timer;
import javax.swing.JTextField;

public class quiz {
	private static String user;

    public JFrame frmWelcome;
    public JRadioButton[] radioButtons;
    public JButton nextButton;
    public int currentQuestion;
    public int score;
    public JLabel resultLabel;
    public JLabel questionLabel;
    public Timer timer;
    public JLabel timerLabel;
    public int remainingTime;
    public Color defaultBackgroundColor;
    public int selectedOption; // Variable to store the index of the selected option

    // Define the quiz questions and options
    public String[][] quizData = {
            {"Question 1: What is the capital of India?", "Delhi", "Kolkata", "Mumbai", "Chennai", "Delhi"},
            {"Question 2: Which planet is known as the Largest Planet?", "Mars", "Venus", "Jupiter", "Saturn", "Jupiter"},
            {"Question 3: Who is the father of mathematics in India?", "Gaddam karthik", "Nikhil cheryala", "Srinivasa Ramanujan", "Gudla Gowtham", "Srinivasa Ramanujan"},
            {"Question 4: Who is the author of the Harry Potter series?", "J.K. Rowling", "Stephen King", "George R.R. Martin", "J.R.R. Tolkien", "J.K. Rowling"},
            {"Question 5: What is the largest continent?", "Asia", "Africa", "North America", "South America", "Asia"},
            {"Question 6: What is the chemical symbol for gold?", "Au", "Ag", "Fe", "Cu", "Au"},
            {"Question 7: Who is the Romeo in SPSU University?", "Karthik Gaddam", "Nikhil cheryala", "Vishnu vardhan", "Gudla gowtham", "Karthik Gaddam"},
            {"Question 8: What is the tallest mountain in the world?", "Mount Everest", "K2", "Kangchenjunga", "Makalu", "Mount Everest"},
            {"Question 9: Who is the Best marvel Fan in SPSU?", "Gudla gowtham", "Karthik Gaddam", "Nikhil cheryala", "Shrihari", "Gudla gowtham"},
            {"Question 10: What is the capital of Telangana?", "Siddipet", "Karimnagar", "Hyderabad", "Nizambad", "Hyderabad"}
    };

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    quiz window = new quiz(user);
                    window.frmWelcome.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public quiz(String user) {
    	
        
        initialize(user);
    }

    /**
     * Initialize the contents of the frame.
     */
    public void initialize(String user) {

        frmWelcome = new JFrame();
        frmWelcome.setTitle("WELCOME "+user);
        frmWelcome.setBounds(100, 100, 450, 300);
        frmWelcome.setVisible(true);
        frmWelcome.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmWelcome.getContentPane().setLayout(null);

        questionLabel = new JLabel("");
        questionLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        questionLabel.setBounds(45, 20, 400, 21);
        frmWelcome.getContentPane().add(questionLabel);

        ButtonGroup bg = new ButtonGroup();
        radioButtons = new JRadioButton[4];
        for (int i = 0; i < 4; i++) {
            radioButtons[i] = new JRadioButton("");
            radioButtons[i].setBounds(45, 74 + (i * 33), 400, 21);
            frmWelcome.getContentPane().add(radioButtons[i]);
            bg.add(radioButtons[i]);
        }
        defaultBackgroundColor = frmWelcome.getContentPane().getBackground();
        nextButton = new JButton("Next");
        nextButton.setBounds(251, 216, 85, 21);
        frmWelcome.getContentPane().add(nextButton);

        resultLabel = new JLabel("");
        resultLabel.setBounds(45, 216, 150, 21);
        frmWelcome.getContentPane().add(resultLabel);

        timerLabel = new JLabel("Time remaining: 30 seconds");
        timerLabel.setBounds(45, 50, 150, 21);
        frmWelcome.getContentPane().add(timerLabel);

        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                checkAnswer();
                if (currentQuestion < quizData.length - 1) {
                    currentQuestion++;
                    showQuestion(currentQuestion);
                } else {
                    showResult();
                }
            }
        });

        currentQuestion = 0;
        score = 0;
        showQuestion(currentQuestion);
    }

    public void showQuestion(int questionIndex) {
        frmWelcome.getContentPane().setBackground(defaultBackgroundColor);
        startTimer();

        String[] questionData = quizData[questionIndex];
        questionLabel.setText(questionData[0]);
        clearSelection(); // Clear the previously selected radio button
        for (int i = 0; i < 4; i++) {
            radioButtons[i].setText(questionData[i + 1]);
            radioButtons[i].setSelected(false);
        }
        nextButton.setEnabled(true); // Enable the "Next" button
        resultLabel.setText("");
    }

    public void clearSelection() {
        for (JRadioButton radioButton : radioButtons) {
            radioButton.setSelected(false);
        }
        selectedOption = -1; // Reset the selected option index
        resetOptionColors(); // Reset the option colors to default
    }

    public void startTimer() {
        remainingTime = 30;
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                remainingTime--;
                if (remainingTime >= 0) {
                    timerLabel.setText("Time remaining: " + remainingTime + " seconds");
                    frmWelcome.repaint(); // Add this line to update the frame
                } else {
                    showResult();
                }
            }
        });
        timer.setInitialDelay(0);
        timer.start();
    }

    public void checkAnswer() {
        String selectedAnswer = null;
        for (int i = 0; i < 4; i++) {
            if (radioButtons[i].isSelected()) {
                selectedAnswer = radioButtons[i].getText();
                selectedOption = i; // Store the index of the selected option
                break;
            }
        }

        if (selectedAnswer != null) {
            String correctAnswer = quizData[currentQuestion][5];
            if (selectedAnswer.equals(correctAnswer)) {
                score++;
                
                radioButtons[selectedOption].setBackground(Color.GREEN); // Change the background color to green
                JOptionPane.showMessageDialog(frmWelcome, "Correct!");
            } else {
                
                radioButtons[selectedOption].setBackground(Color.RED); // Change the background color to red
                JOptionPane.showMessageDialog(frmWelcome, "Wrong! ");
            }
        } else {
            
            JOptionPane.showMessageDialog(frmWelcome, "No answer selected");
        }
        timer.stop();
    }

    public void showResult() {
        resultLabel.setText("Your score: " + score + "/" + quizData.length);
        nextButton.setEnabled(false);
        timer.stop();
    }

    public void resetOptionColors() {
        for (JRadioButton radioButton : radioButtons) {
            radioButton.setBackground(defaultBackgroundColor);
        }
    }
}
