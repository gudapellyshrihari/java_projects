package sep2023;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.Timer;

public class Quizz {
    private String user;
    private JFrame frmWelcome;
    private JRadioButton[] radioButtons;
    private JButton nextButton;
    private int currentQuestion;
    private int score;
    private JLabel resultLabel;
    private JLabel questionLabel;
    private Timer timer;
    private JLabel timerLabel;
    private int remainingTime;
    private Color defaultBackgroundColor;
    private int selectedOption; // Variable to store the index of the selected option
    private JComboBox<String> languageComboBox;
    private String selectedLanguage;

    // Define the quiz questions and options
    private String[][] javaQuizData = {
    		{"Question 1: Which of the following is not a primitive data type in Java?", "int", "float", "char", "class", "class"},
            {"Question 2: How do you declare a constant variable in Java?", "final", "static", "constant", "const", "final"},
            {"Question 3: What is the output of the following code snippet?\nint x = 10;\nSystem.out.println(x++);\nSystem.out.println(++x);", "10\n12", "11\n12", "10\n11", "11\n11", "10\n12"},
            {"Question 4: What is the purpose of the 'static' keyword in Java?", "To create a class instance", "To access instance variables", "To declare a constant", "To define a static method", "To define a static method"},
            {"Question 5: Which keyword is used to create an object in Java?", "new", "create", "class", "object", "new"},
            {"Question 6: What is the default value of a boolean variable in Java?", "true", "false", "0", "null", "false"},
            {"Question 7: How do you convert a string to an integer in Java?", "Integer.parseInt()", "String.valueOf()", "toInt()", "cast operator", "Integer.parseInt()"},
            {"Question 8: What is the output of the following code snippet?\nString s1 = \"Hello\";\nString s2 = new String(\"Hello\");\nSystem.out.println(s1 == s2);", "true", "false", "compile error", "runtime error", "false"},
            {"Question 9: What is the purpose of the 'this' keyword in Java?", "To refer to the current object", "To create a new object", "To access superclass members", "To call static methods", "To refer to the current object"},
            {"Question 10: What is the difference between '== ' and '.equals()' in Java?", "'==' compares object references, while '.equals()' compares object values", "'==' compares object values, while '.equals()' compares object references", "'==' is used for primitive types, while '.equals()' is used for objects", "There is no difference between '==' and '.equals()' in Java", "'==' compares object references, while '.equals()' compares object values"}
        
        // Java quiz questions and options
    };

    private String[][] pythonQuizData = {
    		{"Question 1: How do you declare a variable in Python?", "var", "let", "int", "No keyword needed", "No keyword needed"},
            {"Question 2: What is the output of the following code snippet?\nx = 5\nprint(\"The value of x is\", x)", "The value of x is 5", "The value of x is 0", "The value of x is garbage", "The value of x is undefined", "The value of x is 5"},
            {"Question 3: How do you create a list in Python?", "list[]", "list()", "{}", "()", "list()"},
            {"Question 4: What is the purpose of the 'for' loop in Python?", "To iterate over a sequence", "To define a function", "To check conditions", "To declare a variable", "To iterate over a sequence"},
            {"Question 5: Which of the following is not a valid data type in Python?", "int", "float", "string", "boolean", "boolean"},
            {"Question 6: What is the correct syntax for defining a function in Python?", "def myFunction:", "function myFunction():", "myFunction():", "define myFunction():", "def myFunction:"},
            {"Question 7: How do you remove an element from a list in Python?", "remove()", "pop()", "delete()", "erase()", "remove()"},
            {"Question 8: What is the output of the following code snippet?\nmyList = [1, 2, 3, 4, 5]\nprint(myList[2:4])", "[3, 4]", "[2, 3]", "[1, 2]", "[4, 5]", "[3, 4]"},
            {"Question 9: What is the purpose of the 'pass' statement in Python?", "To do nothing", "To terminate a loop", "To return a value", "To skip to the next iteration", "To do nothing"},
            {"Question 10: What is the difference between a tuple and a list in Python?", "Lists are mutable, while tuples are immutable", "Lists can contain elements of different data types, while tuples can only contain elements of the same data type", "Lists have a fixed size, while tuples can grow or shrink", "There is no difference between a tuple and a list in Python", "Lists are mutable, while tuples are immutable"}
    };

    private String[][] cppQuizData = {
    		{"Question 1: What is the extension for C++ source code files?", ".cpp", ".java", ".py", ".c", ".cpp"},
            {"Question 2: Which C++ keyword is used to define a class?", "class", "interface", "struct", "object", "class"},
            {"Question 3: What is the output of the following code snippet?\n#include <iostream>\nusing namespace std;\nint main() {\n   int x = 5;\n   cout << \"The value of x is \" << x << endl;\n   return 0;\n}", "The value of x is 5", "The value of x is 0", "The value of x is garbage", "The value of x is undefined", "The value of x is 5"},
            {"Question 4: What is the purpose of the 'new' operator in C++?", "Allocate memory", "Delete memory", "Create objects", "Declare variables", "Allocate memory"},
            {"Question 5: What is the correct syntax for inheriting a class in C++?", "class ChildClass extends ParentClass", "class ChildClass : public ParentClass", "class ChildClass -> ParentClass", "class ChildClass > ParentClass", "class ChildClass : public ParentClass"},
            {"Question 6: What is the default access modifier for members of a class in C++?", "private", "public", "protected", "default", "private"},
            {"Question 7: What is the use of the 'friend' keyword in C++?", "To declare a function as a friend", "To declare a class as a friend", "To declare a variable as a friend", "To declare a namespace as a friend", "To declare a function as a friend"},
            {"Question 8: What is the output of the following code snippet?\nint numbers[] = {1, 2, 3, 4, 5};\nint* ptr = numbers;\ncout << *(ptr + 2);", "1", "2", "3", "4", "3"},
            {"Question 9: What is the purpose of the 'const' keyword in C++?", "To declare a constant variable", "To declare a class as constant", "To declare a function as constant", "To declare a loop as constant", "To declare a constant variable"},
            {"Question 10: What is the difference between 'struct' and 'class' in C++?", "Structs have public members by default, while classes have private members by default", "Structs are used for procedural programming, while classes are used for object-oriented programming", "Structs can have member functions, while classes cannot", "There is no difference between 'struct' and 'class' in C++", "Structs have public members by default, while classes have private members by default"}
    };

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Quizz window = new Quizz();
                    window.frmWelcome.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Quizz() {
        initialize();
    }

    public void initialize() {
    	frmWelcome = new JFrame();
        frmWelcome.setTitle("WELCOME " + user);
        frmWelcome.setBounds(100, 100, 450, 300);
        frmWelcome.setVisible(true);
        frmWelcome.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmWelcome.getContentPane().setLayout(new FlowLayout());

        // Create and initialize the languageComboBox
        JComboBox<String> languageComboBox = new JComboBox<String>();
        languageComboBox.setBounds(45, 20, 150, 21);
        languageComboBox.addItem("C++");
        languageComboBox.addItem("Java");
        languageComboBox.addItem("Python");
        frmWelcome.getContentPane().add(languageComboBox);

        // Set the selectedLanguage to the first language option
        selectedLanguage = (String) languageComboBox.getItemAt(0);

        // Add ActionListener to the languageComboBox
        languageComboBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JComboBox<String> combo = (JComboBox<String>) e.getSource();
                selectedLanguage = (String) combo.getSelectedItem();
                resetQuiz(); // Reset the quiz with the selected language
            }
        });

        questionLabel = new JLabel("");
        questionLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        questionLabel.setBounds(45, 60, 400, 21);
        frmWelcome.getContentPane().add(questionLabel);

        ButtonGroup bg = new ButtonGroup();
        radioButtons = new JRadioButton[4];
        for (int i = 0; i < 4; i++) {
            radioButtons[i] = new JRadioButton("");
            radioButtons[i].setBounds(45, 110 + (i * 33), 400, 21);
            frmWelcome.getContentPane().add(radioButtons[i]);
            bg.add(radioButtons[i]);
        }
        defaultBackgroundColor = frmWelcome.getContentPane().getBackground();
        nextButton = new JButton("Next");
        nextButton.setBounds(251, 216, 85, 21);
        frmWelcome.getContentPane().add(nextButton);

        resultLabel = new JLabel("");
        resultLabel.setBounds(45, 216, 150, 21);
        frmWelcome.getContentPane().add(resultLabel);

        timerLabel = new JLabel("Time remaining: 30 seconds");
        timerLabel.setBounds(45, 90, 150, 21);
        frmWelcome.getContentPane().add(timerLabel);

        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                checkAnswer();
                if (currentQuestion < getQuizData().length - 1) {
                    currentQuestion++;
                    showQuestion(currentQuestion);
                } else {
                    showResult();
                }
            }
        });

        resetQuiz();
    }

    public String[][] getQuizData() {
        if (selectedLanguage.equals("Java")) {
            return javaQuizData;
        } else if (selectedLanguage.equals("Python")) {
            return pythonQuizData;
        } else if (selectedLanguage.equals("C++")) {
            return cppQuizData;
        } else {
            return null;
        }
    }

    public void resetQuiz() {
        currentQuestion = 0;
        score = 0;
        showQuestion(currentQuestion);
        resultLabel.setText("");
        timerLabel.setText("Time remaining: 30 seconds");
        timerLabel.setForeground(Color.BLACK);
        nextButton.setEnabled(true);
        radioButtons[0].requestFocus();
        clearSelection();
    }

    public void showQuestion(int questionIndex) {
        frmWelcome.getContentPane().setBackground(defaultBackgroundColor);
        startTimer();

        String[] questionData = getQuizData()[questionIndex];
        questionLabel.setText(questionData[0]);
        clearSelection();
        for (int i = 0; i < 4; i++) {
            radioButtons[i].setText(questionData[i + 1]);
            radioButtons[i].setSelected(false);
        }
    }

    public void clearSelection() {
        for (JRadioButton radioButton : radioButtons) {
            radioButton.setSelected(false);
        }
        selectedOption = -1;
        resetOptionColors();
    }

    public void startTimer() {
        remainingTime = 30;
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                remainingTime--;
                if (remainingTime >= 0) {
                    timerLabel.setText("Time remaining: " + remainingTime + " seconds");
                    if (remainingTime <= 5) {
                        timerLabel.setForeground(Color.RED);
                    }
                    frmWelcome.repaint();
                } else {
                    showResult();
                }
            }
        });
        timer.setInitialDelay(0);
        timer.start();
    }

    public void checkAnswer() {
        String selectedAnswer = null;
        for (int i = 0; i < 4; i++) {
            if (radioButtons[i].isSelected()) {
                selectedAnswer = radioButtons[i].getText();
                selectedOption = i;
                break;
            }
        }

        if (selectedAnswer != null) {
            String correctAnswer = getQuizData()[currentQuestion][5];
            if (selectedAnswer.equals(correctAnswer)) {
                score++;
                radioButtons[selectedOption].setBackground(Color.GREEN);
                JOptionPane.showMessageDialog(frmWelcome, "Correct!");
            } else {
                radioButtons[selectedOption].setBackground(Color.RED);
                JOptionPane.showMessageDialog(frmWelcome, "Wrong!");
            }
        } else {
            JOptionPane.showMessageDialog(frmWelcome, "No answer selected");
        }
        timer.stop();
    }

    public void showResult() {
        resultLabel.setText("Your score: " + score + "/" + getQuizData().length);
        nextButton.setEnabled(false);
        timer.stop();
    }

    public void resetOptionColors() {
        for (JRadioButton radioButton : radioButtons) {
            radioButton.setBackground(defaultBackgroundColor);
        }
    }
}
