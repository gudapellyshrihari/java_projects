package sep2023;

import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.SystemColor;
public class Totalbackend {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
Connection con;
Statement stmt;
ResultSet rs;
private JTextField textField_7;
protected JTable table;
private JTable table_1;
private JTable table_2;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Totalbackend window = new Totalbackend();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Totalbackend() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 546, 394);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(21, 11, 489, 319);
		frame.getContentPane().add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Add Record", null, panel, null);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("RollNo");
		lblNewLabel.setBounds(21, 25, 48, 14);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(106, 22, 96, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(21, 65, 48, 14);
		panel.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setText("");
		textField_1.setBounds(106, 62, 96, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("City");
		lblNewLabel_2.setBounds(21, 102, 48, 14);
		panel.add(lblNewLabel_2);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Udaipur", "Jaipur", "Chandigarh", "AMritsar"}));
		comboBox.setBounds(106, 98, 96, 22);
		panel.add(comboBox);
		
		JLabel lblNewLabel_3 = new JLabel("Gender");
		lblNewLabel_3.setBounds(21, 141, 48, 14);
		panel.add(lblNewLabel_3);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
		rdbtnNewRadioButton.setSelected(true);
		rdbtnNewRadioButton.setBounds(93, 137, 109, 23);
		panel.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Female");
		rdbtnNewRadioButton_1.setBounds(202, 137, 109, 23);
		panel.add(rdbtnNewRadioButton_1);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				int roll=Integer.parseInt(textField.getText());
				String name=textField_1.getText();
				String city=(String)comboBox.getSelectedItem();
				char gen='M';
				if(rdbtnNewRadioButton.isSelected())
					gen='M';
				else
					gen='F';
				
				long contact=Long.parseLong(textField_2.getText());
			try {
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","OerB2969+1");
				PreparedStatement ps=con.prepareStatement("insert into data values(?,?,?,?,?)");
				ps.setInt(1, roll);
				ps.setString(2, name);
				ps.setString(3, city);
				ps.setString(4, String.valueOf(gen));
				ps.setLong(5, contact);
				int n=ps.executeUpdate();
				if(n>0)
					JOptionPane.showMessageDialog(frame, "Record Inserted Successfully");
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}		
			
			}
		});
		btnNewButton.setBounds(106, 235, 89, 23);
		panel.add(btnNewButton);
		
		textField_2 = new JTextField();
		textField_2.setBounds(106, 183, 96, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Contact");
		lblNewLabel_4.setBounds(21, 186, 48, 14);
		panel.add(lblNewLabel_4);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("View and Update", null, panel_1, null);
		panel_1.setLayout(null);
		
		textField_3 = new JTextField();
		textField_3.setEnabled(false);
		textField_3.setBounds(172, 11, 96, 20);
		panel_1.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Roll No");
		lblNewLabel_5.setBounds(44, 14, 48, 14);
		panel_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Name");
		lblNewLabel_6.setBounds(44, 66, 48, 14);
		panel_1.add(lblNewLabel_6);
		
		textField_4 = new JTextField();
		textField_4.setEnabled(false);
		textField_4.setText("");
		textField_4.setBounds(172, 63, 96, 20);
		panel_1.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("City");
		lblNewLabel_7.setBounds(44, 123, 48, 14);
		panel_1.add(lblNewLabel_7);
		
		textField_5 = new JTextField();
		textField_5.setEnabled(false);
		textField_5.setText("");
		textField_5.setBounds(172, 120, 96, 20);
		panel_1.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Gender");
		lblNewLabel_8.setBounds(44, 180, 48, 14);
		panel_1.add(lblNewLabel_8);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("M");
		rdbtnNewRadioButton_2.setEnabled(false);
		rdbtnNewRadioButton_2.setBounds(177, 176, 48, 23);
		panel_1.add(rdbtnNewRadioButton_2);
		
		JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("F");
		rdbtnNewRadioButton_3.setEnabled(false);
		rdbtnNewRadioButton_3.setBounds(227, 176, 36, 23);
		panel_1.add(rdbtnNewRadioButton_3);
		
		JLabel lblNewLabel_9 = new JLabel("Contact");
		lblNewLabel_9.setBounds(44, 235, 48, 14);
		panel_1.add(lblNewLabel_9);
		
		textField_6 = new JTextField();
		textField_6.setEnabled(false);
		textField_6.setText("");
		textField_6.setBounds(172, 232, 96, 20);
		panel_1.add(textField_6);
		textField_6.setColumns(10);
		
		
		
		
		
		
		JButton btnNewButton_4 = new JButton("Edit");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			textField_4.setEnabled(true);
			textField_5.setEnabled(true);
			textField_6.setEnabled(true);
			rdbtnNewRadioButton_2.setEnabled(true);
			rdbtnNewRadioButton_3.setEnabled(true);
			}
		});
		btnNewButton_4.setBounds(288, 119, 89, 23);
		panel_1.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Update");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int roll=Integer.parseInt(textField_3.getText());
				String name=textField_4.getText();
				String city=textField_5.getText();
				char gen='M';
				if(rdbtnNewRadioButton_2.isSelected())
					gen='M';
				else
					gen='F';
				
				long contact=Long.parseLong(textField_6.getText());
			
			try {
				PreparedStatement pst=con.prepareStatement("update data set name=?,city=?,gender=?,contact=? where Rno=?");
				
				pst.setString(1, name);
				pst.setString(2,city);
				pst.setString(3, String.valueOf(gen));
				pst.setLong(4, contact);
				pst.setInt(5, roll);
				int n=pst.executeUpdate();
				if(n>0)
					JOptionPane.showMessageDialog(frame, "Record updated successfully");
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			}
		});
		btnNewButton_5.setBounds(385, 119, 89, 23);
		panel_1.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Delete");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				int op=JOptionPane.showConfirmDialog(frame, "are you sure to delete a current record");
			if(op==0)
				try {
					stmt.executeUpdate("delete from data where Rno="+textField_3.getText());
					JOptionPane.showMessageDialog(frame, "Record deleted Successfully");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_6.setBounds(288, 153, 89, 23);
		panel_1.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("First");
		btnNewButton_7.setBounds(288, 187, 89, 23);
		panel_1.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("Last");
		btnNewButton_8.setBounds(387, 187, 89, 23);
		panel_1.add(btnNewButton_8);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(293, 10, 68, 22);
		panel_1.add(comboBox_1);
		
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","OerB2969+1");
			stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);
			rs=stmt.executeQuery("show tables");
			while(rs.next())
			{
				comboBox_1.addItem(rs.getString(1));
			}
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		JButton btnNewButton_1 = new JButton("Load Table");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				String tablename=(String)comboBox_1.getSelectedItem();
			try {
				rs=stmt.executeQuery("select * from "+tablename);
				if(rs.next())
				{
					textField_3.setText(String.valueOf(rs.getInt(1)));
					textField_4.setText(rs.getString(2));
					textField_5.setText(rs.getString(3));
					if(rs.getString(4).charAt(0)=='M')
						rdbtnNewRadioButton_2.setSelected(true);
					else
						rdbtnNewRadioButton_3.setSelected(true);
					textField_6.setText(rs.getString(5));
					
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			}
		});
		btnNewButton_1.setBackground(SystemColor.activeCaption);
		btnNewButton_1.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnNewButton_1.setBounds(371, 10, 103, 23);
		panel_1.add(btnNewButton_1);
		JButton btnNewButton_2 = new JButton("Next");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				try {
					if(rs.next())
					{
						textField_3.setText(String.valueOf(rs.getInt(1)));
						textField_4.setText(rs.getString(2));
						textField_5.setText(rs.getString(3));
						if(rs.getString(4).charAt(0)=='M')
							rdbtnNewRadioButton_2.setSelected(true);
						else
							rdbtnNewRadioButton_3.setSelected(true);
						textField_6.setText(rs.getString(5));
						
					}
					else
						JOptionPane.showMessageDialog(frame, "you are on last Record");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
					
			
			}
		});
		btnNewButton_2.setBounds(288, 85, 89, 23);
		panel_1.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Previous");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(rs.previous())
					{
						textField_3.setText(String.valueOf(rs.getInt(1)));
						textField_4.setText(rs.getString(2));
						textField_5.setText(rs.getString(3));
						if(rs.getString(4).charAt(0)=='M')
							rdbtnNewRadioButton_2.setSelected(true);
						else
							rdbtnNewRadioButton_3.setSelected(true);
						textField_6.setText(rs.getString(5));
						
					}
					else
						JOptionPane.showMessageDialog(frame, "you are on first Record");
				} catch (HeadlessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
			
			}
		});
		btnNewButton_3.setBounds(387, 85, 89, 23);
		panel_1.add(btnNewButton_3);
		JButton btnNewButton_9 = new JButton("Refresh");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			try {
				rs=stmt.executeQuery("select * from data");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
		});
		btnNewButton_9.setBounds(385, 153, 89, 23);
		panel_1.add(btnNewButton_9);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("New tab", null, panel_2, null);
		panel_2.setLayout(null);
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(150, 143, 99, 22);
		panel_2.add(comboBox_2);
		JButton btnNewButton_10 = new JButton("Show Data");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				try {
					rs=stmt.executeQuery("select * from data");
								
				ResultSetMetaData rsm=rs.getMetaData();
				String s[]=new String[rsm.getColumnCount()];
				
				int in=1;
				for(int i=0;i<rsm.getColumnCount();i++)
					{
						comboBox_2.addItem((String)rsm.getColumnName(in));
						s[i]=rsm.getColumnName(in);
						++in;
					}
				
				rs.last();
				int row=rs.getRow();
				Object[][] data=new Object[row][rsm.getColumnCount()];
				rs.beforeFirst();
				int i=0;
				while(rs.next())
				{int j=0;
					data[i][j++]=rs.getInt(1);
					data[i][j++]=rs.getString(2);
					data[i][j++]=rs.getString(3);
					data[i][j++]=rs.getString(4);
					data[i][j++]=rs.getLong(5);
					
					
					i++;
				}
				JTable table = new JTable(data,s);
				
				//frame.getContentPane().add(table);
				table.setBounds(56, 77, 304, 82);
				JScrollPane scrollPane = new JScrollPane(table);
				scrollPane.setBounds(30, 78, 450, 80);
				frame.getContentPane().add(scrollPane);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_10.setBounds(135, 11, 148, 23);
		panel_2.add(btnNewButton_10);
		
		
		
		JLabel lblNewLabel_10 = new JLabel("Column Name");
		lblNewLabel_10.setBounds(25, 147, 99, 14);
		panel_2.add(lblNewLabel_10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(284, 144, 96, 20);
		panel_2.add(textField_7);
		textField_7.setColumns(10);
		
		JButton btnNewButton_11 = new JButton("Show");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String s1=(String)comboBox_2.getSelectedItem();

					String s2=textField_7.getText();
					stmt = con.createStatement();
					rs=stmt.executeQuery("select * from data where "+s1+"="+"'"+s2+"'");


					

					// Creating the table model
					DefaultTableModel model = new DefaultTableModel();
					table_2.setModel(model);

					// Adding columns to the table model
					ResultSetMetaData rsmd = rs.getMetaData();
					int columnCount = rsmd.getColumnCount();
					for (int i = 1; i <= columnCount; i++) {
						model.addColumn(rsmd.getColumnName(i));
					}

					// Adding rows to the table model
					while (rs.next()) {
						Object[] row = new Object[columnCount];
						for (int i = 1; i <= columnCount; i++) {
							row[i - 1] = rs.getObject(i);
						}
						model.addRow(row);
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_11.setBounds(385, 142, 89, 23);
		panel_2.add(btnNewButton_11);
		
		
		
		table_2 = new JTable();
		table_2.setBounds(35, 187, 387, 83);
		panel_2.add(table_2);
		
		
		
		
		String columnsName[]= {"RollNO","Name","Branch"};
		String data[][]= {
							{"1","Amit","CSE"},
							{"2","bhavik","CSE"}
						 };
		
		
		
		
	}
}
