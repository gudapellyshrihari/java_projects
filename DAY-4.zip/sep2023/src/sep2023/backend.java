package sep2023;
import java.sql.*;
public class backend {
	backend()
	{
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/java","root","OerB2969+1");
			PreparedStatement ps=con.prepareStatement("select * from mytable",ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);;
			ResultSet rs=ps.executeQuery();
			ResultSetMetaData rsm=rs.getMetaData();
			System.out.println(rsm.getColumnCount());
			System.out.println(rsm.getColumnName(1));
			
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+""
						           +rs.getString(2)+""
						           +rs.getString(3)+""
						           +rs.getInt(4)+""
						           +rs.getString(5)+"");
			}
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
	}
	public static void main(String args[])
	{
		new backend();
	}

}
