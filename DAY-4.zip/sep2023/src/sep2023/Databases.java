package sep2023;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JScrollPane;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import javax.swing.JLabel;


public class Databases {

    private JFrame frame;
    private JComboBox<String> comboBox;
    private JComboBox<String> comboBox_1;
    private JTable table;
    private Connection connection;
    private Vector<String> databases;
    private Vector<String> tables;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Databases window = new Databases();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public Databases() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 540, 476);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        comboBox = new JComboBox<String>();
        comboBox.setBounds(24, 42, 88, 21);
        frame.getContentPane().add(comboBox);

        JButton btnNewButton = new JButton("Select Database");
        btnNewButton.setBounds(182, 42, 114, 21);
        frame.getContentPane().add(btnNewButton);

        comboBox_1 = new JComboBox<String>();
        comboBox_1.setBounds(24, 108, 88, 21);
        frame.getContentPane().add(comboBox_1);

        JButton btnNewButton_1 = new JButton("Select Table");
        btnNewButton_1.setBounds(182, 108, 114, 21);
        frame.getContentPane().add(btnNewButton_1);

        table = new JTable();
        table.setBounds(24, 176, 377, 77);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 176, 506, 190);
        frame.getContentPane().add(scrollPane);
        
        JLabel lblNewLabel = new JLabel("DATABASE SELECTION");
        lblNewLabel.setBounds(24, 10, 132, 22);
        frame.getContentPane().add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel("TABEL SELECTION");
        lblNewLabel_1.setBounds(24, 73, 108, 25);
        frame.getContentPane().add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("DISPLAYING THE DATA:");
        lblNewLabel_2.setBounds(33, 139, 139, 23);
        frame.getContentPane().add(lblNewLabel_2);


        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedDatabase = (String) comboBox.getSelectedItem();
                if (selectedDatabase != null) {
                    try {
                        loadTables(selectedDatabase);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
            
        });

        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectedTable = (String) comboBox_1.getSelectedItem();
                if (selectedTable != null) {
                	try {
                        String selectedTable1 = (String) comboBox_1.getSelectedItem();
                        loadTableData(selectedTable1);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        connectToDatabase();
        loadDatabases();
        frame.setVisible(true);
    }

    private void connectToDatabase() {
       
        String url = "jdbc:mysql://localhost:3306/";
        String username = "root";
        String password = "OerB2969+1";

        try {
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadDatabases() {
        databases = new Vector<String>();

        try {
            DatabaseMetaData metaData = connection.getMetaData();
            ResultSet resultSet = metaData.getCatalogs();

            while (resultSet.next()) {
                String databaseName = resultSet.getString("TABLE_CAT");
                databases.add(databaseName);
            }

            comboBox.setModel(new DefaultComboBoxModel<String>(databases));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadTables(String databaseName) throws SQLException {
        tables = new Vector<String>();

        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet resultSet = metaData.getTables(databaseName, null, "%", null);

        while (resultSet.next()) {
            String tableName = resultSet.getString("TABLE_NAME");
            tables.add(tableName);
        }

        comboBox_1.setModel(new DefaultComboBoxModel<String>(tables));
    }

    private void loadTableData(String tableName) throws SQLException {
        DefaultTableModel model = new DefaultTableModel();

        String selectedDatabase = (String) comboBox.getSelectedItem();
        String query = "SELECT * FROM " + selectedDatabase + "." + tableName;
        ResultSet resultSet = connection.createStatement().executeQuery(query);
        ResultSetMetaData rsMetaData = (ResultSetMetaData) resultSet.getMetaData();
        int columnCount = rsMetaData.getColumnCount();

        // Add column names to the model
        for (int i = 1; i <= columnCount; i++) {
            String columnName = rsMetaData.getColumnName(i);
            model.addColumn(columnName);
        }

        //resultset r=ps/executeQuery("show tables")
        while (resultSet.next()) {
            Vector<Object> row = new Vector<Object>();

            for (int i = 1; i <= columnCount; i++) {
                row.add(resultSet.getObject(i));
            }

            model.addRow(row);
        }

        table.setModel(model);
    }
}
