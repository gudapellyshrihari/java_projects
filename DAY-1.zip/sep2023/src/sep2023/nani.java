package sep2023;
import java.util.Random;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JProgressBar;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
public class nani {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					nani window = new nani();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public nani() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 282, 300);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JLayeredPane layeredPane = new JLayeredPane();
		frame.getContentPane().add(layeredPane, BorderLayout.CENTER);
		
		JButton btnNewButton = new JButton("Factorial");
		btnNewButton.addActionListener(new ActionListener() {
			private String s;

			public void actionPerformed(ActionEvent e) {
				s = JOptionPane.showInputDialog(frame, "Enter a number:", "Factorial Calculator", JOptionPane.QUESTION_MESSAGE);
				//String input = null;
				int number = Integer.parseInt(s);
		        
		        // Calculate the factorial
		        int factorial = calculateFactorial(number);
		        
		        // Display the result in a message dialog
		        JOptionPane.showMessageDialog(null, "Factorial of " + number + " is: " + factorial, "Factorial Result", JOptionPane.INFORMATION_MESSAGE);
			
			}
			private static int calculateFactorial(int number) {
		        if (number == 0 || number == 1) {
		            return 1;
		        } else {
		            return number * calculateFactorial(number - 1);
		        }
		    }
		});
		btnNewButton.setBounds(20, 54, 85, 21);
		layeredPane.add(btnNewButton);
		
		JButton BMI = new JButton("BMI");
		BMI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String weightInput = JOptionPane.showInputDialog(frame, "Enter your weight (in kilograms):",
						"BMI Calculator", JOptionPane.QUESTION_MESSAGE);
				double weight = Double.parseDouble(weightInput);

				String heightInput = JOptionPane.showInputDialog(frame, "Enter your height (in meters):",
						"BMI Calculator", JOptionPane.QUESTION_MESSAGE);
				double height = Double.parseDouble(heightInput);

				double bmi = calculateBMI(weight, height);

				JOptionPane.showMessageDialog(null, "Your BMI is: " + bmi, "BMI Result",
						JOptionPane.INFORMATION_MESSAGE);
				if(bmi<16)
				{
					JOptionPane.showMessageDialog(frame,"Severe Thinness","Improvement needed",JOptionPane.INFORMATION_MESSAGE);
				}
				else if(bmi<17 && bmi>16)
				{
					JOptionPane.showMessageDialog(frame,"Moderate Thinness","Improvement needed",JOptionPane.INFORMATION_MESSAGE);
				}
				else if(bmi<18.5 && bmi>17)
				{
					JOptionPane.showMessageDialog(frame,"Mild Thinness","Improvement needed",JOptionPane.INFORMATION_MESSAGE);
				}
				else if(bmi<25 && bmi>18.5)
				{
					JOptionPane.showMessageDialog(frame,"Normal","Perfectly Alright",JOptionPane.INFORMATION_MESSAGE);
				}
				else if(bmi<30 && bmi>25)
				{
					JOptionPane.showMessageDialog(frame,"Overweight","Reduce Weight",JOptionPane.INFORMATION_MESSAGE);
				}
				else if(bmi<35 && bmi>30)
				{
					JOptionPane.showMessageDialog(frame,"Obese-Class-I","Reduce Weight",JOptionPane.INFORMATION_MESSAGE);
				}
				else if(bmi<40 && bmi>35)
				{
					JOptionPane.showMessageDialog(frame,"Obese-Class-II","Reduce Weight",JOptionPane.INFORMATION_MESSAGE);
				}
				else if(bmi<45 && bmi>40)
				{
					JOptionPane.showMessageDialog(frame,"Obese-Class-III","Reduce Weight",JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					JOptionPane.showMessageDialog(frame,"Invalid","Wrong Value",JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});
		BMI.setBounds(162, 72, 85, 21);
		layeredPane.add(BMI);
		
		JButton btnNewButton_1 = new JButton("calci");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num1Input = JOptionPane.showInputDialog(frame, "Enter the first number:",
						"Calculator", JOptionPane.QUESTION_MESSAGE);
				double num1 = Double.parseDouble(num1Input);

				String num2Input = JOptionPane.showInputDialog(frame, "Enter the second number:",
						"Calculator", JOptionPane.QUESTION_MESSAGE);
				double num2 = Double.parseDouble(num2Input);

				double sum = num1 + num2;
				double difference = num1 - num2;
				double product = num1 * num2;
				double quotient = num1 / num2;
				String choice = JOptionPane.showInputDialog(frame, "Enter your choice:\n1.sum:\n2.subraction\n3.multiplication\n4.Division",
						"Calculator", JOptionPane.QUESTION_MESSAGE);
				String message=null;
				switch(choice) {
				case "1":
					 message = "Sum: " + sum;
					break;
				case "2":
					 message = "Difference: " + difference;
					break;
				case "3":
					 message = "Product: " + product;
					break;
				case "4":
					 message = "Division: " + quotient;
					break;
				default:
					JOptionPane.showMessageDialog(null, "Invalid operation selected!",
							"Calculator Error", JOptionPane.ERROR_MESSAGE);
					return;
			}

				

				JOptionPane.showMessageDialog(null, message, "Calculator Result",
						JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_1.setBounds(162, 20, 85, 21);
		layeredPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("TEMP(C)");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new convertor();			}
		});
		btnNewButton_2.setBounds(162, 120, 85, 21);
		layeredPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("RPS");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] options = { "Rock", "Paper", "Scissors" };
			    String userChoice = (String) JOptionPane.showInputDialog(frame, "Select your choice:", "Rock-Paper-Scissors",
			            JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

			    String computerChoice = getRandomChoice();

			    String result = determineWinner(userChoice, computerChoice);

			    String message = "Your choice: " + userChoice + "\nComputer's choice: " + computerChoice + "\nResult: " + result;

			    JOptionPane.showMessageDialog(null, message, "Rock-Paper-Scissors Result", JOptionPane.INFORMATION_MESSAGE);
				
			}
		});
		btnNewButton_3.setBounds(162, 173, 85, 21);
		layeredPane.add(btnNewButton_3);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(28, 214, 146, 11);
		layeredPane.add(progressBar);
		
		JComboBox<String> comboBox = new JComboBox<>();

		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedCity = (String) comboBox.getSelectedItem();
                JOptionPane.showMessageDialog(frame, "Selected City: " + selectedCity, "City Selection",
                        JOptionPane.INFORMATION_MESSAGE);
				
			}
		});
		comboBox.setMaximumRowCount(20);
		comboBox.setModel(new DefaultComboBoxModel<>(new String[] {"Siddipet", "hyderabad"}));

		comboBox.setBounds(28, 99, 85, 21);
		layeredPane.add(comboBox);
	}

	protected double calculateBMI(double weight, double height) {
		return (weight / (height * height))*10000;
	}

	protected int calculateFactorial(int number) {
		// TODO Auto-generated method stub
		return 0;
	}
	private static double fahrenheitToCelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }

    private static double celsiusToFahrenheit(double celsius) {
        return celsius * 9 / 5 + 32;
    }

    private static double kelvinToCelsius(double kelvin) {
        return kelvin - 273.15;
    }

    private static double celsiusToKelvin(double celsius) {
        return celsius + 273.15;
    }

    @SuppressWarnings("unused")
	private static double fahrenheitToKelvin(final double fahrenheit) {
        return celsiusToKelvin(fahrenheitToCelsius(fahrenheit));
    }

    @SuppressWarnings("unused")
	private static double kelvinToFahrenheit(double kelvin) {
        return celsiusToFahrenheit(kelvinToCelsius(kelvin));
    }
    private String getRandomChoice() {
        String[] choices = { "Rock", "Paper", "Scissors" };
        Random random = new Random();
        int index = random.nextInt(choices.length);
        return choices[index];
    }

    private String determineWinner(String userChoice, String computerChoice) {
        if (userChoice.equals(computerChoice)) {
            return "It's a tie!";
        } else if (userChoice.equals("Rock") && computerChoice.equals("Scissors")
                || userChoice.equals("Paper") && computerChoice.equals("Rock")
                || userChoice.equals("Scissors") && computerChoice.equals("Paper")) {
            return "You win!";
        } else {
            return "Computer wins!";
        }
    }
}
