package sep2023;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class dialog extends JFrame {
    private JTextField numField;
    private JButton[] numberButtons;
    private JButton addButton;
    private JButton subtractButton;
    private JButton multiplyButton;
    private JButton divideButton;
    private JButton clearButton;
    private JButton equalToButton; // New button for calculating the result
    private JLabel resultLabel;

    private StringBuilder numStringBuilder;
    private double num1;
    private double num2;
    private String operation;

    private boolean isFirstNumberEntered;

    public dialog() {
        setTitle("Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(10, 5));

        numField = new JTextField();
        numField.setEditable(false);
        add(new JLabel("Number:"));
        add(numField);

        numberButtons = new JButton[10];
        for (int i = 0; i < numberButtons.length; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].addActionListener(new NumberButtonListener());
            add(numberButtons[i]);
        }

        addButton = new JButton("Add");
        subtractButton = new JButton("Subtract");
        multiplyButton = new JButton("Multiply");
        divideButton = new JButton("Divide");
        clearButton = new JButton("Clear");
        equalToButton = new JButton("="); // New "Equal To" button

        addButton.addActionListener(new OperationListener());
        subtractButton.addActionListener(new OperationListener());
        multiplyButton.addActionListener(new OperationListener());
        divideButton.addActionListener(new OperationListener());
        clearButton.addActionListener(new ClearButtonListener());
        equalToButton.addActionListener(new EqualButtonListener()); // Register the new listener

        add(addButton);
        add(subtractButton);
        add(multiplyButton);
        add(divideButton);
        add(clearButton);
        add(equalToButton); // Add the "Equal To" button

        resultLabel = new JLabel("Result: ");
        add(resultLabel);

        numStringBuilder = new StringBuilder();
        num1 = 0;
        num2 = 0;
        operation = "";
        isFirstNumberEntered = false;

        pack();
        setVisible(true);
    }

    private class NumberButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton source = (JButton) e.getSource();
            String numberText = source.getText();

            if (numStringBuilder.length() == 0 && numberText.equals("0")) {
                // Ignore leading zeros
                return;
            }

            numStringBuilder.append(numberText);
            numField.setText(numStringBuilder.toString());
        }
    }

    private class OperationListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton source = (JButton) e.getSource();
            operation = source.getText();

            if (!isFirstNumberEntered) {
                num1 = Double.parseDouble(numStringBuilder.toString());
                numStringBuilder.setLength(0);
                numField.setText("");
                isFirstNumberEntered = true;
            }
        }
    }

    private class EqualButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (isFirstNumberEntered) {
                num2 = Double.parseDouble(numStringBuilder.toString());

                double result = 0;

                switch (operation) {
                    case "Add":
                        result = num1 + num2;
                        break;
                    case "Subtract":
                        result = num1 - num2;
                        break;
                    case "Multiply":
                        result = num1 * num2;
                        break;
                    case "Divide":
                        result = num1 / num2;
                        break;
                    default:
                        break;
                }

                resultLabel.setText("Result: " + result);

                numStringBuilder.setLength(0);
                numField.setText("");
                isFirstNumberEntered = false;
            }
        }
    }

    private class ClearButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            numStringBuilder.setLength(0);
            numField.setText("");
            resultLabel.setText("Result: ");
            num1 = 0;
            num2 = 0;
            operation = "";
            isFirstNumberEntered = false;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new dialog();
            }
        });
    }
}
